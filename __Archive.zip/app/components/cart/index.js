import Cart from './cart.component';

export default Cart;
