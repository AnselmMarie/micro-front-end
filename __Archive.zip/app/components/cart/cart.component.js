/* Node Modules */
import React from 'react';

export default () => <div>Cart Data</div>;
