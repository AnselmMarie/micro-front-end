import Header from './header.component';
import './header.styles.css';

export default Header;
