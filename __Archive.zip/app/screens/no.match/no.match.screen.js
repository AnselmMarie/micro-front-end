/* Node Modules */
import React from 'react';
/* Components */
import Header from '../../components/header';

export default () => (
    <>
        <Header />
        <div>Wrong Page</div>
    </>
);
