/* Node Modules */
import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.css';
/* Modules */
import Navigation from '../../modules/navigation';

ReactDOM.render(<Navigation />, document.getElementById('app'));
