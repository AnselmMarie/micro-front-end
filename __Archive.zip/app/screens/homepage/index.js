import Homepage from './homepage.screen';
import './homepage.styles.css';

export default Homepage;
