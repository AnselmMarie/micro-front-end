import ShopItems from './shop.items.component';

export default ShopItems;
